import { useApp } from '../context/AppContext';
import HeroGown from './HeroGown';

export default function Hero() {
  const { scrollToCollections } = useApp();

  return (
    <section id="hero">
      <div className="hero-grid">
        <div className="hero-text">
          <div className="hero-eyebrow">New Collection — 2026</div>
          <h1 className="hero-title">
            Where <em>Luxury</em>
            <br />
            Meets
            <br />
            Artistry
          </h1>
          <p className="hero-subtitle">
            Opaluxe is more than fashion. Each piece is a testament to the mastery of craft, the
            finest materials, and the timeless pursuit of beauty.
          </p>
          <button className="hero-cta" onClick={scrollToCollections}>
            Explore Collections <span className="hero-cta-arrow">→</span>
          </button>
        </div>
        <div className="hero-visual">
          <HeroGown />
        </div>
      </div>
    </section>
  );
}

import { StoryMonogramSVG } from './DecorativeArt';

export default function BrandStory() {
  return (
    <section id="story">
      <div className="story-inner">
        <div className="story-text">
          <span className="section-eyebrow">Our Philosophy</span>
          <h2 className="story-title">
            Crafted with
            <br />
            <em>Intention</em>
          </h2>
          <p className="story-body">
            Opaluxe was born from a singular belief: that true luxury is not worn — it is
            inhabited. Our ateliers in Paris and Milan produce each piece by hand, using only the
            finest silks, cashmeres, and hand-dyed fabrics sourced from heritage mills with
            centuries of craft behind them.
          </p>
          <p className="story-body">
            Every Opaluxe garment carries a handwritten production number and the signature of the
            lead artisan who created it.
          </p>
          <div className="story-stats">
            <div>
              <span className="stat-number">12+</span>
              <span className="stat-label">Years of Craft</span>
            </div>
            <div>
              <span className="stat-number">48</span>
              <span className="stat-label">Artisan Ateliers</span>
            </div>
            <div>
              <span className="stat-number">100%</span>
              <span className="stat-label">Hand-Finished</span>
            </div>
          </div>
        </div>
        <div className="story-visual">
          <StoryMonogramSVG />
        </div>
      </div>
    </section>
  );
}

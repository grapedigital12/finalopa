import { useApp } from '../context/AppContext';
import ShowcaseItem from './ShowcaseItem';
import ProductCard from './ProductCard';

const SIZES = ['XS', 'S', 'M', 'L', 'XL'];
const COLORS = ['Midnight Black', 'Ivory', 'Champagne Gold', 'Deep Bordeaux', 'Slate Grey'];
const PRICES = ['Under $1,500', '$1,500–$3,000', '$3,000–$5,000', '$5,000+'];

export default function CollectionPage() {
  const { showPage, currentCollection } = useApp();

  return (
    <div className="page" id="page-collection">
      <div className="collection-hero">
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <button className="collection-breadcrumb" onClick={() => showPage('home')}>
            ← Back to <span>Opaluxe</span>
          </button>
          <h1 className="collection-page-title">
            {currentCollection.titlePlain} <em>{currentCollection.titleEm}</em>
          </h1>
          <p className="collection-page-subtitle">{currentCollection.subtitle}</p>
        </div>
      </div>

      <div className="collection-3d-showcase">
        <div className="showcase-title">
          Explore the <em>Silhouettes</em>
        </div>
        <p className="showcase-subtitle">Hover to pause — click to add to bag</p>
        <div className="showcase-row">
          {currentCollection.products.slice(0, 4).map((p, i) => (
            <ShowcaseItem product={p} index={i} key={p.id} />
          ))}
        </div>
      </div>

      <div className="shop-body">
        <aside className="shop-filters">
          <h3>Refine</h3>
          <div className="filter-group">
            <div className="filter-group-title">Size</div>
            {SIZES.map((s) => (
              <label className="filter-option" key={s}>
                <input type="checkbox" /> {s}
              </label>
            ))}
          </div>
          <div className="filter-group">
            <div className="filter-group-title">Colour</div>
            {COLORS.map((c) => (
              <label className="filter-option" key={c}>
                <input type="checkbox" /> {c}
              </label>
            ))}
          </div>
          <div className="filter-group">
            <div className="filter-group-title">Price</div>
            {PRICES.map((p) => (
              <label className="filter-option" key={p}>
                <input type="checkbox" /> {p}
              </label>
            ))}
          </div>
        </aside>
        <div className="product-grid">
          {currentCollection.products.map((p, i) => (
            <ProductCard product={p} index={i} key={p.id} />
          ))}
        </div>
      </div>
    </div>
  );
}

import { useEffect, useState } from 'react';

export default function WelcomePopup() {
  const [visible, setVisible] = useState(true);
  const [closing, setClosing] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [firstName, setFirstName] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [errors, setErrors] = useState({});

  useEffect(() => {
    // Lock scroll while popup is open, matching original behavior.
    if (visible) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [visible]);

  if (!visible) return null;

  const close = () => {
    setClosing(true);
    setTimeout(() => setVisible(false), 350);
  };

  const formatPhone = (raw) => {
    let v = raw.replace(/\D/g, '').substring(0, 11);
    if (v.length > 7) v = '+' + v[0] + ' (' + v.slice(1, 4) + ') ' + v.slice(4, 7) + '-' + v.slice(7);
    else if (v.length > 4) v = '+' + v[0] + ' (' + v.slice(1, 4) + ') ' + v.slice(4);
    else if (v.length > 1) v = '+' + v[0] + ' (' + v.slice(1);
    return v;
  };

  const submit = () => {
    const trimmedName = name.trim();
    const trimmedEmail = email.trim();
    const trimmedPhone = phone.trim();

    if (!trimmedName) {
      setErrors({ name: true });
      return;
    }
    if (!trimmedEmail || !trimmedEmail.includes('@')) {
      setErrors({ email: true });
      return;
    }
    if (!trimmedPhone) {
      setErrors({ phone: true });
      return;
    }
    setErrors({});
    setFirstName(trimmedName.split(' ')[0] + '.');
    setSubmitted(true);
  };

  return (
    <div
      className="popup-overlay"
      id="popupOverlay"
      style={
        closing
          ? { transition: 'opacity .35s ease', opacity: 0, pointerEvents: 'none' }
          : undefined
      }
    >
      <div className="popup-box">
        <div className="popup-left">
          <div className="popup-left-bg" />
          <div className="popup-left-ornament" />
          <div className="popup-brand">
            OPAL<span>U</span>XE
          </div>
          <div className="popup-left-body">
            <div className="popup-left-eyebrow">Welcome to the Maison</div>
            <h2 className="popup-left-title">
              Join the
              <br />
              <em>Inner Circle</em>
            </h2>
            <p className="popup-left-desc">
              Be the first to know about new collections, private sales, and exclusive events
              reserved for Opaluxe members.
            </p>
          </div>
          <div className="popup-perks">
            <div className="popup-perk">
              <div className="popup-perk-dot" />
              Early access to new arrivals
            </div>
            <div className="popup-perk">
              <div className="popup-perk-dot" />
              Exclusive member-only pricing
            </div>
            <div className="popup-perk">
              <div className="popup-perk-dot" />
              Invitations to private events
            </div>
            <div className="popup-perk">
              <div className="popup-perk-dot" />
              Complimentary gift wrapping
            </div>
          </div>
        </div>

        <div className="popup-right">
          <button className="popup-close" onClick={close}>✕</button>

          {!submitted ? (
            <div>
              <div className="popup-form-eyebrow">Members Only</div>
              <h3 className="popup-form-title">
                Create Your
                <br />
                Account
              </h3>
              <p className="popup-form-sub">A world of luxury awaits. Sign up in seconds.</p>
              <div className="popup-fields">
                <div className="popup-field">
                  <label>Full Name</label>
                  <input
                    type="text"
                    placeholder="Isabelle Moreau"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className={errors.name ? 'field-error' : ''}
                  />
                </div>
                <div className="popup-field">
                  <label>Email Address</label>
                  <input
                    type="email"
                    placeholder="your@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={errors.email ? 'field-error' : ''}
                  />
                </div>
                <div className="popup-field">
                  <label>Phone Number</label>
                  <input
                    type="tel"
                    placeholder="+1 (000) 000-0000"
                    value={phone}
                    onChange={(e) => setPhone(formatPhone(e.target.value))}
                    className={errors.phone ? 'field-error' : ''}
                  />
                </div>
              </div>
              <button className="popup-submit" onClick={submit}>
                Join Opaluxe →
              </button>
              <button className="popup-skip" onClick={close}>
                No thank you, continue browsing
              </button>
              <p className="popup-privacy">
                Your details are kept private and never shared.
                <br />
                Unsubscribe at any time.
              </p>
            </div>
          ) : (
            <div className="popup-success">
              <div className="popup-success-check">✓</div>
              <div className="popup-success-title">
                Welcome,
                <br />
                <em>{firstName}</em>
              </div>
              <p className="popup-success-body">
                You're now part of the Opaluxe inner circle. Expect something special in your
                inbox very soon.
              </p>
              <button className="popup-success-close" onClick={close}>
                Enter the Maison →
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

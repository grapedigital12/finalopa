import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatPrice } from '../data/collections';
import DressSVG from './DressSVG';

export default function CheckoutPage() {
  const { cart, cartTotal, placeOrder, showToast } = useApp();
  const [email, setEmail] = useState('');
  const [first, setFirst] = useState('');
  const [last, setLast] = useState('');
  const [cardNum, setCardNum] = useState('');
  const [cardExp, setCardExp] = useState('');

  const formatCard = (raw) => {
    const v = raw.replace(/\D/g, '').substring(0, 16);
    return v.replace(/(.{4})/g, '$1 ').trim();
  };

  const formatExp = (raw) => {
    let v = raw.replace(/\D/g, '').substring(0, 4);
    if (v.length >= 2) v = v.substring(0, 2) + ' / ' + v.substring(2);
    return v;
  };

  const handlePlaceOrder = () => {
    if (!email || !first) {
      showToast('Please complete all required fields.');
      return;
    }
    if (!cardNum || cardNum.replace(/\s/g, '').length < 12) {
      showToast('Please enter a valid card number.');
      return;
    }
    placeOrder();
  };

  return (
    <div className="page" id="page-checkout">
      <div className="checkout-body">
        <div>
          <h1 className="checkout-form-title">Checkout</h1>

          <div className="form-section">
            <div className="form-section-title">Contact Information</div>
            <div className="form-row full">
              <div className="form-field">
                <label>Email Address</label>
                <input
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>
            <div className="form-row">
              <div className="form-field">
                <label>First Name</label>
                <input
                  type="text"
                  placeholder="Isabelle"
                  value={first}
                  onChange={(e) => setFirst(e.target.value)}
                />
              </div>
              <div className="form-field">
                <label>Last Name</label>
                <input
                  type="text"
                  placeholder="Moreau"
                  value={last}
                  onChange={(e) => setLast(e.target.value)}
                />
              </div>
            </div>
            <div className="form-row full">
              <div className="form-field">
                <label>Phone</label>
                <input type="tel" placeholder="+1 (000) 000-0000" />
              </div>
            </div>
          </div>

          <div className="form-section">
            <div className="form-section-title">Shipping Address</div>
            <div className="form-row full">
              <div className="form-field">
                <label>Address Line 1</label>
                <input type="text" placeholder="123 Avenue Montaigne" />
              </div>
            </div>
            <div className="form-row full">
              <div className="form-field">
                <label>Address Line 2</label>
                <input type="text" placeholder="Suite, Apt, etc." />
              </div>
            </div>
            <div className="form-row">
              <div className="form-field">
                <label>City</label>
                <input type="text" placeholder="Paris" />
              </div>
              <div className="form-field">
                <label>Postal Code</label>
                <input type="text" placeholder="75008" />
              </div>
            </div>
            <div className="form-row full">
              <div className="form-field">
                <label>Country</label>
                <select defaultValue="France">
                  <option>France</option>
                  <option>United States</option>
                  <option>United Kingdom</option>
                  <option>Italy</option>
                  <option>Japan</option>
                  <option>UAE</option>
                  <option>Singapore</option>
                </select>
              </div>
            </div>
          </div>

          <div className="form-section">
            <div className="form-section-title">Payment Details</div>
            <div className="form-row full">
              <div className="form-field">
                <label>Card Number</label>
                <input
                  type="text"
                  placeholder="•••• •••• •••• ••••"
                  maxLength={19}
                  value={cardNum}
                  onChange={(e) => setCardNum(formatCard(e.target.value))}
                />
              </div>
            </div>
            <div className="form-row">
              <div className="form-field">
                <label>Expiry Date</label>
                <input
                  type="text"
                  placeholder="MM / YY"
                  maxLength={7}
                  value={cardExp}
                  onChange={(e) => setCardExp(formatExp(e.target.value))}
                />
              </div>
              <div className="form-field">
                <label>CVV</label>
                <input type="text" placeholder="•••" maxLength={3} />
              </div>
            </div>
            <div className="form-row full">
              <div className="form-field">
                <label>Name on Card</label>
                <input type="text" placeholder="Isabelle Moreau" />
              </div>
            </div>
          </div>
        </div>

        <div>
          <div className="order-summary">
            <div className="order-summary-title">Order Summary</div>
            <div>
              {cart.map((item, i) => (
                <div className="order-item" key={item.id}>
                  <div className="order-item-img">
                    <DressSVG color={item.color} accent={item.accent} type={i} />
                  </div>
                  <div className="order-item-details">
                    <div className="order-item-name">{item.name}</div>
                    <div className="order-item-size">
                      {item.material} · Qty {item.qty}
                    </div>
                    <div className="order-item-price">{formatPrice(item.price * item.qty)}</div>
                  </div>
                </div>
              ))}
            </div>
            <hr className="order-divider" />
            <div className="order-line">
              <span>Subtotal</span>
              <span>{formatPrice(cartTotal)}</span>
            </div>
            <div className="order-line">
              <span>Shipping</span>
              <span>Complimentary</span>
            </div>
            <div className="order-line">
              <span>Duties &amp; Taxes</span>
              <span>Included</span>
            </div>
            <div className="order-total">
              <span>Total</span>
              <span>{formatPrice(cartTotal)}</span>
            </div>
            <button className="place-order-btn" onClick={handlePlaceOrder}>
              Place Order →
            </button>
            <p style={{ fontSize: '0.7rem', color: 'var(--muted)', textAlign: 'center', marginTop: 16, lineHeight: 1.5 }}>
              Your order is protected by our complimentary
              <br />
              authentication guarantee.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

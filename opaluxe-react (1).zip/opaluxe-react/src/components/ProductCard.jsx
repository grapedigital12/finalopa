import { useApp } from '../context/AppContext';
import { formatPrice } from '../data/collections';
import DressSVG from './DressSVG';

export default function ProductCard({ product, index }) {
  const { addToCart } = useApp();

  return (
    <div className="product-card" style={{ transitionDelay: `${index * 0.05}s` }}>
      <div className="product-img">
        {product.badge && <div className="product-badge">{product.badge}</div>}
        <DressSVG color={product.color} accent={product.accent} type={index} />
      </div>
      <div className="product-info">
        <div className="product-name">{product.name}</div>
        <div className="product-material">{product.material}</div>
        <div className="product-price-row">
          <div className="product-price">{formatPrice(product.price)}</div>
          <button
            className="add-to-cart-btn"
            onClick={(e) => {
              e.stopPropagation();
              addToCart(product.id);
            }}
          >
            Add to Bag
          </button>
        </div>
      </div>
    </div>
  );
}

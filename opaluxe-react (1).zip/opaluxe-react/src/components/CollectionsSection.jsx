import { useApp } from '../context/AppContext';
import { useFadeUp } from '../hooks/useFadeUp';
import { EveningGownSVG, StreetWearSVG, BridalSVG } from './CollectionArt';

function CollectionCard({ onClick, visual, category, name, desc, price, delay, visualBg }) {
  const ref = useFadeUp();
  return (
    <div
      className="collection-card fade-up"
      ref={ref}
      onClick={onClick}
      style={delay ? { transitionDelay: delay } : undefined}
    >
      <div className="card-arrow">→</div>
      <div className="card-visual" style={visualBg ? { background: visualBg } : undefined}>
        {visual}
      </div>
      <div className="card-info">
        <div className="card-category">{category}</div>
        <div className="card-name">{name}</div>
        <div className="card-desc">{desc}</div>
        <div className="card-price">{price}</div>
      </div>
    </div>
  );
}

export default function CollectionsSection() {
  const { openCollection } = useApp();
  const headerRef = useFadeUp();

  return (
    <section id="collections">
      <div className="section-header fade-up" ref={headerRef}>
        <span className="section-eyebrow">The Collections</span>
        <h2 className="section-title">
          Curated for the
          <br />
          <em>Discerning Few</em>
        </h2>
      </div>
      <div className="collection-grid">
        <CollectionCard
          onClick={() => openCollection('evening')}
          visual={<EveningGownSVG />}
          category="Signature Collection"
          name="Evening Gowns"
          desc="Floor-sweeping drama for the moments that demand to be remembered. Each gown, a masterpiece."
          price="From $2,850"
        />
        <CollectionCard
          onClick={() => openCollection('street')}
          visual={<StreetWearSVG />}
          category="Urban Luxury"
          name="Street Wear"
          desc="The meeting point of effortless cool and couture precision. Luxury, redefined for the streets."
          price="From $890"
          delay=".1s"
          visualBg="linear-gradient(145deg,#e8e4de,#d5cec5)"
        />
        <CollectionCard
          onClick={() => openCollection('bridal')}
          visual={<BridalSVG />}
          category="Bridal Couture"
          name="Bridal"
          desc="For the day that stands above all others. Ethereal craftsmanship for the modern bride."
          price="From $4,200"
          delay=".2s"
          visualBg="linear-gradient(145deg,#f8f3ee,#f0e8dc)"
        />
      </div>
    </section>
  );
}

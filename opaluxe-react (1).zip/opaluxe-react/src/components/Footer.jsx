import { useApp } from '../context/AppContext';

export default function Footer() {
  const { showPage, openCollection } = useApp();

  return (
    <footer>
      <div className="footer-inner">
        <div className="footer-brand">
          <span className="nav-logo" onClick={() => showPage('home')}>
            OPAL<span>U</span>XE
          </span>
          <p className="footer-tagline">
            "Where luxury is not worn —
            <br />
            it is inhabited."
          </p>
        </div>
        <div className="footer-col">
          <div className="footer-col-title">Collections</div>
          <ul>
            <li onClick={() => openCollection('evening')}>Evening Gowns</li>
            <li onClick={() => openCollection('street')}>Street Wear</li>
            <li onClick={() => openCollection('bridal')}>Bridal Couture</li>
            <li>Resort Collection</li>
            <li>Accessories</li>
          </ul>
        </div>
        <div className="footer-col">
          <div className="footer-col-title">Maison</div>
          <ul>
            <li>Our Story</li>
            <li>Ateliers</li>
            <li>Sustainability</li>
            <li>Press</li>
            <li>Careers</li>
          </ul>
        </div>
        <div className="footer-col">
          <div className="footer-col-title">Client Services</div>
          <ul>
            <li>Size Guide</li>
            <li>Bespoke Orders</li>
            <li>Alterations</li>
            <li>Contact</li>
            <li>Returns &amp; Care</li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© 2026 Opaluxe Maison de Couture. All rights reserved.</span>
        <span>Privacy · Terms · Accessibility</span>
      </div>
    </footer>
  );
}

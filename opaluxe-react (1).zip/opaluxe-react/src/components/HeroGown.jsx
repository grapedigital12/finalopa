export default function HeroGown() {
  return (
    <div className="dress-stage">
      <div className="dress-3d">
        <svg viewBox="0 0 280 400" xmlns="http://www.w3.org/2000/svg" className="dress-svg">
          <defs>
            <radialGradient id="gownGrad" cx="50%" cy="30%" r="60%">
              <stop offset="0%" stopColor="#E8D9C5" />
              <stop offset="100%" stopColor="#C9A96E" />
            </radialGradient>
            <radialGradient id="bodyGrad" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#F5CBA7" />
              <stop offset="100%" stopColor="#E59866" />
            </radialGradient>
            <filter id="softGlow">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
            <linearGradient id="sheen" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="rgba(255,255,255,0.4)" />
              <stop offset="50%" stopColor="rgba(255,255,255,0)" />
              <stop offset="100%" stopColor="rgba(201,169,110,0.3)" />
            </linearGradient>
          </defs>

          <ellipse cx="140" cy="350" rx="100" ry="18" fill="rgba(0,0,0,0.08)" />
          <path
            d="M80,180 Q40,250 20,380 Q80,360 140,370 Q200,360 260,380 Q240,250 200,180 Z"
            fill="url(#gownGrad)"
            filter="url(#softGlow)"
          />
          <path
            d="M80,180 Q40,250 20,380 Q80,360 140,370 Q200,360 260,380 Q240,250 200,180 Z"
            fill="url(#sheen)"
            opacity="0.6"
          />
          <path d="M120,200 Q100,280 90,360" stroke="rgba(255,255,255,0.3)" strokeWidth="1" fill="none" />
          <path d="M160,200 Q155,285 155,365" stroke="rgba(255,255,255,0.2)" strokeWidth="1" fill="none" />
          <path d="M185,205 Q200,280 205,355" stroke="rgba(255,255,255,0.2)" strokeWidth="1" fill="none" />

          <path
            d="M95,120 Q85,150 80,180 L200,180 Q195,150 185,120 Q165,105 140,105 Q115,105 95,120 Z"
            fill="#C9A96E"
          />
          <path
            d="M110,125 Q100,150 97,178 L183,178 Q180,150 170,125 Q155,112 140,112 Q125,112 110,125 Z"
            fill="#B8965A"
          />
          <line x1="140" y1="112" x2="140" y2="178" stroke="rgba(255,255,255,0.25)" strokeWidth="1" />

          <path
            d="M95,120 Q80,110 70,100 Q90,92 110,108 Q125,98 140,95 Q155,98 170,108 Q190,92 210,100 Q200,110 185,120"
            fill="#C9A96E"
          />

          <ellipse cx="140" cy="62" rx="28" ry="32" fill="url(#bodyGrad)" />
          <path
            d="M112,55 Q108,40 118,28 Q128,20 140,18 Q152,20 162,28 Q172,40 168,55"
            fill="#4A3728"
          />
          <path d="M112,55 Q105,70 108,82" stroke="#4A3728" strokeWidth="8" fill="none" strokeLinecap="round" />
          <path d="M168,55 Q175,70 172,82" stroke="#4A3728" strokeWidth="8" fill="none" strokeLinecap="round" />
          <rect x="132" y="90" width="16" height="20" rx="4" fill="#E8A87C" />

          <path d="M70,100 Q50,120 48,155 Q55,158 62,155 Q65,130 80,118 Z" fill="#E8A87C" />
          <path d="M210,100 Q230,120 232,155 Q225,158 218,155 Q215,130 200,118 Z" fill="#E8A87C" />

          <circle cx="140" cy="125" r="4" fill="#FFD700" opacity="0.8" />
          <circle cx="128" cy="135" r="2.5" fill="#FFD700" opacity="0.6" />
          <circle cx="152" cy="135" r="2.5" fill="#FFD700" opacity="0.6" />

          <rect x="88" y="176" width="104" height="8" rx="2" fill="#A07840" opacity="0.7" />

          <circle cx="100" cy="240" r="2" fill="#FFD700" opacity="0.4" />
          <circle cx="175" cy="270" r="1.5" fill="#FFD700" opacity="0.35" />
          <circle cx="130" cy="310" r="2" fill="#FFD700" opacity="0.3" />
          <circle cx="85" cy="330" r="1.5" fill="#FFD700" opacity="0.25" />
          <circle cx="190" cy="340" r="1.5" fill="#FFD700" opacity="0.3" />
        </svg>
      </div>

      <div className="particle" style={{ left: '20%', top: '70%', animationDelay: '0s' }} />
      <div className="particle" style={{ left: '75%', top: '75%', animationDelay: '1.2s' }} />
      <div className="particle" style={{ left: '45%', top: '80%', animationDelay: '2.5s' }} />
      <div className="particle" style={{ left: '60%', top: '85%', animationDelay: '0.8s' }} />
      <div className="particle" style={{ left: '30%', top: '78%', animationDelay: '3.1s' }} />
    </div>
  );
}

import Hero from './Hero';
import Marquee from './Marquee';
import CollectionsSection from './CollectionsSection';
import BrandStory from './BrandStory';
import Footer from './Footer';

export default function HomePage() {
  return (
    <div className="page">
      <Hero />
      <Marquee />
      <CollectionsSection />
      <BrandStory />
      <Footer />
    </div>
  );
}

export function EveningGownSVG() {
  return (
    <svg viewBox="0 0 200 320" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="evGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#1a1a2e" />
          <stop offset="100%" stopColor="#16213e" />
        </linearGradient>
      </defs>
      <ellipse cx="100" cy="295" rx="72" ry="12" fill="rgba(0,0,0,0.12)" />
      <path d="M55,130 Q20,190 10,290 Q55,275 100,280 Q145,275 190,290 Q180,190 145,130 Z" fill="url(#evGrad)" />
      <path
        d="M55,130 Q20,190 10,290 Q55,275 100,280 Q145,275 190,290 Q180,190 145,130 Z"
        fill="rgba(201,169,110,0.08)"
      />
      <circle cx="70" cy="185" r="1.8" fill="#C9A96E" opacity="0.9" />
      <circle cx="120" cy="200" r="1.5" fill="#C9A96E" opacity="0.7" />
      <circle cx="90" cy="230" r="2" fill="#C9A96E" opacity="0.8" />
      <circle cx="145" cy="255" r="1.5" fill="#C9A96E" opacity="0.6" />
      <circle cx="65" cy="260" r="1.8" fill="#C9A96E" opacity="0.7" />
      <circle cx="130" cy="165" r="1.2" fill="#C9A96E" opacity="0.5" />
      <path d="M65,85 Q55,110 55,130 L145,130 Q145,110 135,85 Q118,72 100,70 Q82,72 65,85 Z" fill="#C9A96E" />
      <path
        d="M72,88 Q63,112 63,128 L137,128 Q137,112 128,88 Q112,76 100,75 Q88,76 72,88 Z"
        fill="#B8965A"
        opacity="0.7"
      />
      <path d="M72,88 L100,108 L128,88" stroke="rgba(255,255,255,0.3)" strokeWidth="1" fill="none" />
      <ellipse cx="100" cy="45" rx="20" ry="24" fill="#E8A87C" />
      <path d="M80,40 Q78,24 90,16 Q100,12 110,16 Q122,24 120,40" fill="#2C1A0E" />
      <path d="M80,40 Q74,52 76,62" stroke="#2C1A0E" strokeWidth="6" fill="none" strokeLinecap="round" />
      <path d="M120,40 Q126,52 124,62" stroke="#2C1A0E" strokeWidth="6" fill="none" strokeLinecap="round" />
      <rect x="93" y="66" width="14" height="16" rx="3" fill="#E8A87C" />
      <path d="M55,85 Q38,100 36,128 Q42,131 47,128 Q50,108 62,95 Z" fill="#1a1a2e" />
      <path d="M145,85 Q162,100 164,128 Q158,131 153,128 Q150,108 138,95 Z" fill="#1a1a2e" />
      <rect x="60" y="128" width="80" height="6" rx="1" fill="#9A7830" />
      <circle cx="100" cy="131" r="4" fill="#C9A96E" />
    </svg>
  );
}

export function StreetWearSVG() {
  return (
    <svg viewBox="0 0 200 320" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="stGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#F5F5F0" />
          <stop offset="100%" stopColor="#E0DDD8" />
        </linearGradient>
      </defs>
      <path
        d="M78,195 Q72,250 70,300 Q85,302 92,300 Q96,255 100,225 Q104,255 108,300 Q115,302 130,300 Q128,250 122,195 Z"
        fill="#1C1C1C"
      />
      <path
        d="M52,105 Q40,140 38,195 L162,195 Q160,140 148,105 L130,90 Q115,85 100,84 Q85,85 70,90 Z"
        fill="url(#stGrad)"
      />
      <path d="M100,84 L78,115 L100,130 L122,115 Z" fill="#D4CFC8" />
      <path d="M100,84 L88,112" stroke="rgba(0,0,0,0.12)" strokeWidth="1" fill="none" />
      <path d="M100,84 L112,112" stroke="rgba(0,0,0,0.12)" strokeWidth="1" fill="none" />
      <circle cx="100" cy="148" r="3" fill="rgba(0,0,0,0.2)" />
      <path d="M52,105 Q34,118 30,155 Q36,158 42,155 Q46,128 66,118 Z" fill="url(#stGrad)" />
      <path d="M148,105 Q166,118 170,155 Q164,158 158,155 Q154,128 134,118 Z" fill="url(#stGrad)" />
      <rect x="58" y="190" width="84" height="8" rx="2" fill="#2A2A2A" />
      <rect x="95" y="189" width="10" height="10" rx="1" fill="#C9A96E" />
      <ellipse cx="100" cy="50" rx="20" ry="22" fill="#C68642" />
      <path d="M80,46 Q80,30 100,26 Q120,30 120,46" fill="#1A0A0A" />
      <rect x="93" y="70" width="14" height="14" rx="3" fill="#C68642" />
      <rect x="84" y="47" width="12" height="8" rx="4" fill="#0A0A0A" opacity="0.85" />
      <rect x="103" y="47" width="12" height="8" rx="4" fill="#0A0A0A" opacity="0.85" />
      <line x1="96" y1="51" x2="103" y2="51" stroke="#0A0A0A" strokeWidth="1.5" />
      <ellipse cx="81" cy="304" rx="12" ry="6" fill="#0A0A0A" />
      <ellipse cx="119" cy="304" rx="12" ry="6" fill="#0A0A0A" />
      <path d="M85,108 Q100,118 115,108" stroke="#C9A96E" strokeWidth="1.5" fill="none" opacity="0.8" />
    </svg>
  );
}

export function BridalSVG() {
  return (
    <svg viewBox="0 0 200 320" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="brGrad" cx="50%" cy="30%" r="70%">
          <stop offset="0%" stopColor="#FDFAF5" />
          <stop offset="100%" stopColor="#F0E8DC" />
        </radialGradient>
      </defs>
      <ellipse cx="100" cy="300" rx="82" ry="14" fill="rgba(0,0,0,0.06)" />
      <path d="M44,140 Q5,210 0,300 Q50,285 100,290 Q150,285 200,300 Q195,210 156,140 Z" fill="url(#brGrad)" />
      <path
        d="M55,140 Q30,200 25,285 Q70,272 100,278 Q130,272 175,285 Q170,200 145,140 Z"
        fill="rgba(255,255,255,0.45)"
      />
      <circle cx="72" cy="180" r="1.5" fill="rgba(201,169,110,0.5)" />
      <circle cx="95" cy="200" r="1.5" fill="rgba(201,169,110,0.4)" />
      <circle cx="120" cy="175" r="1.5" fill="rgba(201,169,110,0.5)" />
      <circle cx="80" cy="225" r="1.5" fill="rgba(201,169,110,0.3)" />
      <circle cx="130" cy="220" r="1.5" fill="rgba(201,169,110,0.4)" />
      <circle cx="65" cy="255" r="1.5" fill="rgba(201,169,110,0.3)" />
      <circle cx="140" cy="250" r="1.5" fill="rgba(201,169,110,0.35)" />
      <circle cx="105" cy="265" r="1.5" fill="rgba(201,169,110,0.3)" />
      <path
        d="M60,90 Q50,115 44,140 L156,140 Q150,115 140,90 Q122,78 100,76 Q78,78 60,90 Z"
        fill="rgba(253,250,245,0.95)"
      />
      <path
        d="M68,93 Q58,118 56,138 L144,138 Q142,118 132,93 Q114,82 100,80 Q86,82 68,93 Z"
        stroke="rgba(201,169,110,0.4)"
        strokeWidth="0.8"
        fill="rgba(255,255,255,0.5)"
      />
      <path d="M70,93 Q80,82 100,88 Q120,82 130,93" fill="rgba(253,250,245,0.95)" />
      <circle cx="100" cy="98" r="3" fill="white" stroke="rgba(201,169,110,0.5)" strokeWidth="0.5" />
      <circle cx="90" cy="105" r="2.5" fill="white" stroke="rgba(201,169,110,0.4)" strokeWidth="0.5" />
      <circle cx="110" cy="105" r="2.5" fill="white" stroke="rgba(201,169,110,0.4)" strokeWidth="0.5" />
      <path d="M80,28 Q70,50 68,80 Q84,72 100,70 Q116,72 132,80 Q130,50 120,28 Z" fill="rgba(253,250,245,0.6)" />
      <path d="M80,28 Q50,60 45,100" stroke="rgba(255,255,255,0.8)" strokeWidth="1.5" fill="none" />
      <path d="M120,28 Q150,60 155,100" stroke="rgba(255,255,255,0.8)" strokeWidth="1.5" fill="none" />
      <ellipse cx="100" cy="44" rx="19" ry="21" fill="#E8C9A0" />
      <ellipse cx="100" cy="30" rx="15" ry="10" fill="#4A3728" />
      <path d="M88,26 Q84,18 100,14 Q116,18 112,26" fill="#4A3728" />
      <path
        d="M86,22 L89,16 L93,22 L97,14 L100,22 L103,14 L107,22 L111,16 L114,22"
        stroke="#C9A96E"
        strokeWidth="1.2"
        fill="none"
      />
      <circle cx="100" cy="14" r="2" fill="#C9A96E" />
      <rect x="93" y="62" width="14" height="12" rx="3" fill="#E8C9A0" />
      <path d="M60,90 Q44,102 42,130 Q48,133 53,130 Q56,110 68,100 Z" fill="rgba(253,250,245,0.85)" />
      <path d="M140,90 Q156,102 158,130 Q152,133 147,130 Q144,110 132,100 Z" fill="rgba(253,250,245,0.85)" />
      <circle cx="165" cy="135" r="16" fill="#F9C6C9" opacity="0.7" />
      <circle cx="155" cy="130" r="11" fill="#F0B8BC" opacity="0.8" />
      <circle cx="172" cy="128" r="10" fill="#F5C0C3" opacity="0.75" />
      <circle cx="162" cy="142" r="9" fill="#F0B8BC" opacity="0.7" />
      <circle cx="165" cy="135" r="6" fill="#E8A5A9" opacity="0.6" />
      <line x1="163" y1="150" x2="158" y2="168" stroke="#5C8A3C" strokeWidth="1.5" />
      <line x1="167" y1="152" x2="170" y2="168" stroke="#5C8A3C" strokeWidth="1.5" />
    </svg>
  );
}

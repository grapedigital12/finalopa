export function StoryMonogramSVG() {
  return (
    <svg viewBox="0 0 300 400" width="280" xmlns="http://www.w3.org/2000/svg">
      <rect x="10" y="10" width="280" height="380" rx="2" fill="none" stroke="rgba(201,169,110,0.2)" strokeWidth="1" />
      <rect x="18" y="18" width="264" height="364" rx="2" fill="none" stroke="rgba(201,169,110,0.1)" strokeWidth="0.5" />
      <path d="M10,40 L10,10 L40,10" fill="none" stroke="rgba(201,169,110,0.6)" strokeWidth="1.5" />
      <path d="M260,10 L290,10 L290,40" fill="none" stroke="rgba(201,169,110,0.6)" strokeWidth="1.5" />
      <path d="M10,360 L10,390 L40,390" fill="none" stroke="rgba(201,169,110,0.6)" strokeWidth="1.5" />
      <path d="M260,390 L290,390 L290,360" fill="none" stroke="rgba(201,169,110,0.6)" strokeWidth="1.5" />
      <text x="150" y="220" textAnchor="middle" fontFamily="Playfair Display, serif" fontSize="96" fontWeight="900" fill="rgba(201,169,110,0.15)" letterSpacing="-2">
        O
      </text>
      <text x="150" y="220" textAnchor="middle" fontFamily="Playfair Display, serif" fontSize="28" fontWeight="700" fill="rgba(201,169,110,0.5)" letterSpacing="12">
        OPALUXE
      </text>
      <text x="150" y="248" textAnchor="middle" fontFamily="Cormorant Garamond, serif" fontSize="11" fontStyle="italic" fill="rgba(201,169,110,0.35)">
        Maison de Couture
      </text>
      <line x1="50" y1="265" x2="118" y2="265" stroke="rgba(201,169,110,0.25)" strokeWidth="0.5" />
      <line x1="182" y1="265" x2="250" y2="265" stroke="rgba(201,169,110,0.25)" strokeWidth="0.5" />
      <circle cx="150" cy="265" r="2" fill="rgba(201,169,110,0.4)" />
    </svg>
  );
}

export function ThankYouDressOne() {
  return (
    <svg viewBox="0 0 120 200" width="80" xmlns="http://www.w3.org/2000/svg">
      <path d="M35,80 Q10,120 5,190 Q35,180 60,183 Q85,180 115,190 Q110,120 85,80 Z" fill="#C9A96E" />
      <path d="M40,55 Q35,68 35,80 L85,80 Q85,68 80,55 Q70,46 60,44 Q50,46 40,55 Z" fill="#B8965A" />
      <ellipse cx="60" cy="34" rx="14" ry="16" fill="#E8A87C" />
      <path d="M46,30 Q45,18 60,14 Q75,18 74,30" fill="#2C1A0E" />
      <rect x="53" y="46" width="14" height="10" rx="3" fill="#E8A87C" />
    </svg>
  );
}

export function ThankYouDressTwo() {
  return (
    <svg viewBox="0 0 120 200" width="80" xmlns="http://www.w3.org/2000/svg">
      <path d="M30,80 Q5,120 0,190 Q30,178 60,182 Q90,178 120,190 Q115,120 90,80 Z" fill="#1a1a2e" />
      <path d="M37,55 Q32,68 30,80 L90,80 Q88,68 83,55 Q72,44 60,42 Q48,44 37,55 Z" fill="#C9A96E" />
      <ellipse cx="60" cy="34" rx="14" ry="16" fill="#C68642" />
      <path d="M47,30 Q46,18 60,14 Q74,18 73,30" fill="#1A0A0A" />
      <rect x="53" y="46" width="14" height="10" rx="3" fill="#C68642" />
    </svg>
  );
}

export function ThankYouDressThree() {
  return (
    <svg viewBox="0 0 120 200" width="80" xmlns="http://www.w3.org/2000/svg">
      <path d="M25,80 Q0,120 0,190 Q30,176 60,180 Q90,176 120,190 Q120,120 95,80 Z" fill="#FDFAF5" opacity="0.9" />
      <path d="M36,55 Q30,68 25,80 L95,80 Q90,68 84,55 Q72,43 60,41 Q48,43 36,55 Z" fill="rgba(253,250,245,0.8)" />
      <ellipse cx="60" cy="34" rx="14" ry="16" fill="#E8C9A0" />
      <ellipse cx="60" cy="23" rx="10" ry="7" fill="#4A3728" />
      <rect x="53" y="46" width="14" height="10" rx="3" fill="#E8C9A0" />
    </svg>
  );
}

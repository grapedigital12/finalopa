/**
 * Procedurally-styled dress illustration, used for every product card,
 * cart line item, and order-summary row. There are 3 silhouette
 * variants, rotated by `type % 3`, each recolored via `color` / `accent`.
 */
export default function DressSVG({ color, accent, type = 0, className }) {
  const t = ((type % 3) + 3) % 3;

  if (t === 0) {
    return (
      <svg viewBox="0 0 160 240" xmlns="http://www.w3.org/2000/svg" className={className}>
        <ellipse cx="80" cy="228" rx="58" ry="10" fill="rgba(0,0,0,0.08)" />
        <path d="M38,95 Q15,140 8,220 Q44,208 80,212 Q116,208 152,220 Q145,140 122,95 Z" fill={color} />
        <path d="M38,95 Q15,140 8,220 Q44,208 80,212 Q116,208 152,220 Q145,140 122,95 Z" fill="rgba(255,255,255,0.06)" />
        <path d="M48,62 Q40,78 38,95 L122,95 Q120,78 112,62 Q98,50 80,48 Q62,50 48,62 Z" fill={accent} />
        <line x1="80" y1="48" x2="80" y2="93" stroke="rgba(255,255,255,0.2)" strokeWidth="0.8" />
        <ellipse cx="80" cy="38" rx="16" ry="18" fill="#E8A87C" />
        <path d="M64,34 Q63,20 80,16 Q97,20 96,34" fill="#2C1A0E" />
        <rect x="72" y="53" width="16" height="10" rx="3" fill="#E8A87C" />
        <circle cx="80" cy="70" r="3" fill="rgba(255,255,255,0.4)" />
        <circle cx="68" cy="78" r="2" fill={accent} opacity="0.7" />
        <circle cx="92" cy="78" r="2" fill={accent} opacity="0.7" />
      </svg>
    );
  }

  if (t === 1) {
    return (
      <svg viewBox="0 0 160 240" xmlns="http://www.w3.org/2000/svg" className={className}>
        <ellipse cx="80" cy="228" rx="52" ry="10" fill="rgba(0,0,0,0.08)" />
        <path d="M50,105 Q36,145 30,220 Q56,210 80,214 Q104,210 130,220 Q124,145 110,105 Z" fill={color} />
        <path d="M50,105 Q36,145 30,220 Q56,210 80,214 Q104,210 130,220 Q124,145 110,105 Z" fill="rgba(255,255,255,0.05)" />
        <path d="M52,68 Q44,85 50,105 L110,105 Q116,85 108,68 Q95,55 80,53 Q65,55 52,68 Z" fill={accent} />
        <path d="M52,68 L80,85 L108,68" stroke="rgba(255,255,255,0.25)" strokeWidth="1" fill="none" />
        <ellipse cx="80" cy="40" rx="15" ry="17" fill="#C8956C" />
        <path d="M65,36 Q64,22 80,18 Q96,22 95,36" fill="#1A0A0A" />
        <rect x="72" y="54" width="16" height="10" rx="3" fill="#C8956C" />
        <path d="M44,68 Q28,80 26,108 Q32,110 37,108 Q40,88 52,80 Z" fill={accent} opacity="0.7" />
        <path d="M116,68 Q132,80 134,108 Q128,110 123,108 Q120,88 108,80 Z" fill={accent} opacity="0.7" />
      </svg>
    );
  }

  return (
    <svg viewBox="0 0 160 240" xmlns="http://www.w3.org/2000/svg" className={className}>
      <ellipse cx="80" cy="228" rx="64" ry="12" fill="rgba(0,0,0,0.07)" />
      <path d="M28,100 Q4,148 0,220 Q36,205 80,210 Q124,205 160,220 Q156,148 132,100 Z" fill={color} />
      <path d="M34,100 Q20,145 16,215 Q50,202 80,206 Q110,202 144,215 Q140,145 126,100 Z" fill="rgba(255,255,255,0.06)" />
      <path d="M48,65 Q40,82 28,100 L132,100 Q120,82 112,65 Q98,52 80,50 Q62,52 48,65 Z" fill={accent} />
      <ellipse cx="80" cy="38" rx="16" ry="18" fill="#E0A882" />
      <path d="M64,34 Q62,18 80,14 Q98,18 96,34" fill="#2A180A" />
      <rect x="72" y="54" width="16" height="10" rx="3" fill="#E0A882" />
      <rect x="36" y="98" width="88" height="5" rx="1" fill="rgba(0,0,0,0.15)" />
      <circle cx="80" cy="100" r="4" fill={accent} />
      <circle cx="58" cy="145" r="2" fill={accent} opacity="0.5" />
      <circle cx="106" cy="168" r="2" fill={accent} opacity="0.4" />
      <circle cx="45" cy="185" r="1.5" fill={accent} opacity="0.35" />
    </svg>
  );
}

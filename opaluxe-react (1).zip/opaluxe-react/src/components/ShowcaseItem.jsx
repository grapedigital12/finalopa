import { useApp } from '../context/AppContext';
import DressSVG from './DressSVG';

export default function ShowcaseItem({ product, index }) {
  const { addToCart } = useApp();

  return (
    <button
      className="showcase-item"
      onClick={() => addToCart(product.id)}
      style={{ animationDelay: `${index * -1.5}s` }}
    >
      <div className="showcase-3d" style={{ animationDelay: `${index * -1.5}s` }}>
        <DressSVG color={product.color} accent={product.accent} type={index} />
      </div>
      <div className="showcase-label">{product.name}</div>
    </button>
  );
}

import { useApp } from '../context/AppContext';

export default function Nav() {
  const { showPage, scrollToCollections, cartCount, openCart } = useApp();

  return (
    <nav>
      <button className="nav-logo" onClick={() => showPage('home')}>
        OPAL<span>U</span>XE
      </button>
      <ul className="nav-links">
        <li><a onClick={() => showPage('home')}>Home</a></li>
        <li><a onClick={scrollToCollections}>Collections</a></li>
        <li><a onClick={() => showPage('home')}>Lookbook</a></li>
        <li><a onClick={() => showPage('home')}>About</a></li>
      </ul>
      <button className="nav-cart" onClick={openCart}>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z" />
          <line x1="3" y1="6" x2="21" y2="6" />
          <path d="M16 10a4 4 0 01-8 0" />
        </svg>
        Bag
        <span className="cart-count">{cartCount}</span>
      </button>
    </nav>
  );
}

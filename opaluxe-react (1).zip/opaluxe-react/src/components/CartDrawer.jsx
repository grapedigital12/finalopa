import { useApp } from '../context/AppContext';
import { formatPrice } from '../data/collections';
import DressSVG from './DressSVG';

export default function CartDrawer() {
  const { cart, cartOpen, closeCart, removeFromCart, cartTotal, goToCheckout } = useApp();

  const handleOverlayClick = (e) => {
    if (e.target === e.currentTarget) closeCart();
  };

  return (
    <div className={`cart-overlay${cartOpen ? ' open' : ''}`} onClick={handleOverlayClick}>
      <div className="cart-drawer">
        <div className="cart-header">
          <div className="cart-title" style={{ fontFamily: "'Playfair Display',serif" }}>
            Your Bag
          </div>
          <button className="cart-close" onClick={closeCart}>✕</button>
        </div>

        <div>
          {cart.length === 0 ? (
            <div className="cart-empty">
              Your bag is empty.
              <br />
              <br />
              Explore the collections above.
            </div>
          ) : (
            cart.map((item, idx) => (
              <div className="cart-item" key={item.id}>
                <div className="cart-item-img">
                  <DressSVG color={item.color} accent={item.accent} type={idx} />
                </div>
                <div className="cart-item-details">
                  <div className="cart-item-name">{item.name}</div>
                  <div className="cart-item-meta">{item.material} · Qty {item.qty}</div>
                  <div className="cart-item-price">{formatPrice(item.price)}</div>
                  <button className="cart-item-remove" onClick={() => removeFromCart(idx)}>
                    Remove
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {cart.length > 0 && (
          <div className="cart-footer">
            <div className="cart-subtotal">
              <span>Subtotal</span>
              <span>{formatPrice(cartTotal)}</span>
            </div>
            <div className="cart-subtotal">
              <span>Shipping</span>
              <span>Complimentary</span>
            </div>
            <div className="cart-total">
              <span>Total</span>
              <span>{formatPrice(cartTotal)}</span>
            </div>
            <button className="checkout-btn" onClick={goToCheckout}>
              Proceed to Checkout →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

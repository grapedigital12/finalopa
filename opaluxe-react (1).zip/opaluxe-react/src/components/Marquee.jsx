const ITEMS = ['Evening Gowns', 'Street Luxury', 'Couture Bridal', 'Resort Collection', 'Opaluxe — Est. 2019'];

export default function Marquee() {
  // Render the sequence twice so the CSS marquee animation (translateX -50%) loops seamlessly.
  const sequence = [...ITEMS, ...ITEMS];

  return (
    <div className="marquee-strip">
      <div className="marquee-inner">
        {sequence.map((item, i) => (
          <span key={i}>
            <span className="marquee-item">{item}</span>
            <span className="marquee-item marquee-dot">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}

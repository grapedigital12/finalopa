import { useApp } from '../context/AppContext';
import { ThankYouDressOne, ThankYouDressTwo, ThankYouDressThree } from './DecorativeArt';

export default function ThankYouPage() {
  const { showPage, orderRef } = useApp();

  return (
    <div className="page" id="page-thankyou">
      <div className="ty-bg-text">OPALUXE</div>

      <div className="ty-dress-row">
        <div className="ty-dress"><ThankYouDressOne /></div>
        <div className="ty-dress"><ThankYouDressTwo /></div>
        <div className="ty-dress"><ThankYouDressThree /></div>
      </div>

      <div className="ty-check">✓</div>
      <div className="ty-eyebrow">Order Confirmed</div>
      <h1 className="ty-title">
        Thank You,
        <br />
        <em>Darling.</em>
      </h1>
      <p className="ty-body">
        Your Opaluxe pieces are being carefully prepared by our artisans. Each item undergoes a
        final quality review before being wrapped in our signature packaging.
      </p>
      <p className="ty-body" style={{ marginBottom: 8 }}>
        A confirmation has been sent to your email.
      </p>
      <div className="ty-order-num">
        Order Reference: <span>{orderRef}</span>
      </div>
      <button className="ty-cta" onClick={() => showPage('home')}>
        ← Continue Browsing
      </button>
    </div>
  );
}

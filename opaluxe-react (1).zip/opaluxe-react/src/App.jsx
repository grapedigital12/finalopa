import { AppProvider, useApp } from './context/AppContext';
import Nav from './components/Nav';
import CartDrawer from './components/CartDrawer';
import Toast from './components/Toast';
import WelcomePopup from './components/WelcomePopup';
import HomePage from './components/HomePage';
import CollectionPage from './components/CollectionPage';
import CheckoutPage from './components/CheckoutPage';
import ThankYouPage from './components/ThankYouPage';

function PageRouter() {
  const { page } = useApp();

  switch (page) {
    case 'collection':
      return <CollectionPage />;
    case 'checkout':
      return <CheckoutPage />;
    case 'thankyou':
      return <ThankYouPage />;
    default:
      return <HomePage />;
  }
}

export default function App() {
  return (
    <AppProvider>
      <WelcomePopup />
      <Nav />
      <CartDrawer />
      <Toast />
      <PageRouter />
    </AppProvider>
  );
}

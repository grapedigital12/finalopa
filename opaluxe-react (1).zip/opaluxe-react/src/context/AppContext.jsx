/* eslint-disable react-refresh/only-export-components */
import { createContext, useCallback, useContext, useRef, useState } from 'react';
import { collections } from '../data/collections';

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [page, setPageState] = useState('home');
  const [currentCollectionKey, setCurrentCollectionKey] = useState('evening');
  const [cart, setCart] = useState([]);
  const [toastMsg, setToastMsg] = useState('');
  const [toastShow, setToastShow] = useState(false);
  const [orderRef, setOrderRef] = useState('');
  const [cartOpen, setCartOpen] = useState(false);
  const toastTimer = useRef(null);

  const openCart = useCallback(() => setCartOpen(true), []);
  const closeCart = useCallback(() => setCartOpen(false), []);

  const showPage = useCallback((id) => {
    setPageState(id);
    window.scrollTo(0, 0);
  }, []);

  const scrollToCollections = useCallback(() => {
    showPage('home');
    setTimeout(() => {
      const el = document.getElementById('collections');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 50);
  }, [showPage]);

  const showToast = useCallback((msg) => {
    setToastMsg(msg);
    setToastShow(true);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastShow(false), 3000);
  }, []);

  const openCollection = useCallback((key) => {
    setCurrentCollectionKey(key);
    showPage('collection');
  }, [showPage]);

  const addToCart = useCallback((id) => {
    const col = collections[currentCollectionKey];
    const product = col.products.find((p) => p.id === id);
    if (!product) return;
    setCart((prev) => {
      const existing = prev.find((i) => i.id === id);
      if (existing) {
        return prev.map((i) => (i.id === id ? { ...i, qty: i.qty + 1 } : i));
      }
      return [...prev, { ...product, qty: 1 }];
    });
    showToast(`"${product.name}" added to your bag`);
  }, [currentCollectionKey, showToast]);

  const removeFromCart = useCallback((idx) => {
    setCart((prev) => prev.filter((_, i) => i !== idx));
  }, []);

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);
  const cartTotal = cart.reduce((s, i) => s + i.price * i.qty, 0);

  const placeOrder = useCallback(() => {
    const ref = 'OPX-' + Math.random().toString(36).substring(2, 8).toUpperCase();
    setOrderRef(ref);
    setCart([]);
    showPage('thankyou');
  }, [showPage]);

  const goToCheckout = useCallback(() => {
    closeCart();
    showPage('checkout');
  }, [closeCart, showPage]);

  const value = {
    page,
    showPage,
    scrollToCollections,
    currentCollectionKey,
    currentCollection: collections[currentCollectionKey],
    openCollection,
    cart,
    cartCount,
    cartTotal,
    addToCart,
    removeFromCart,
    toastMsg,
    toastShow,
    showToast,
    orderRef,
    placeOrder,
    cartOpen,
    openCart,
    closeCart,
    goToCheckout,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}

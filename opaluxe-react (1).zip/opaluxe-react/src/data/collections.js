// ══════════════════════════════════════════════════════════════
//  COLLECTION & PRODUCT DATA
// ══════════════════════════════════════════════════════════════
// Each collection's title is split into a plain part and an
// emphasised (italic, gold) part so it can be rendered with JSX
// instead of dangerouslySetInnerHTML.

export const collections = {
  evening: {
    titlePlain: 'Evening',
    titleEm: 'Gowns',
    subtitle: 'Floor-sweeping drama for the moments that demand to be remembered.',
    products: [
      { id: 'e1', name: 'La Nuit Étoilée', material: 'French silk chiffon, hand-beaded', price: 3850, badge: 'Bestseller', color: '#1a1a2e', accent: '#C9A96E' },
      { id: 'e2', name: 'Velvet Reverie', material: 'Italian velvet with silk lining', price: 4200, badge: '', color: '#3D0C11', accent: '#E8A0A0' },
      { id: 'e3', name: 'The Athena', material: 'Draped silk charmeuse', price: 2950, badge: 'New', color: '#2C2C4A', accent: '#DFC48E' },
      { id: 'e4', name: 'Cascade', material: 'Organza with satin underskirt', price: 3100, badge: '', color: '#1C3A30', accent: '#A8C8A8' },
      { id: 'e5', name: 'Obsidian Muse', material: 'Structured mikado silk', price: 5400, badge: 'Limited', color: '#0A0A0A', accent: '#C9A96E' },
      { id: 'e6', name: 'Rose Séraphine', material: 'Blush duchess satin', price: 2850, badge: '', color: '#3D1F2D', accent: '#F5C0C3' },
    ],
  },
  street: {
    titlePlain: 'Street',
    titleEm: 'Wear',
    subtitle: 'The meeting point of effortless cool and couture precision.',
    products: [
      { id: 's1', name: 'Le Blazer Classique', material: 'Virgin wool, unlined', price: 1250, badge: 'Core', color: '#F5F5F0', accent: '#0A0A0A' },
      { id: 's2', name: 'Noir Trench', material: 'Water-repellent gabardine', price: 1890, badge: 'Bestseller', color: '#1C1C1C', accent: '#C9A96E' },
      { id: 's3', name: 'Wide-Leg Couture', material: 'Heavyweight crepe', price: 890, badge: 'New', color: '#4A4A5A', accent: '#DFC48E' },
      { id: 's4', name: 'The Silk Bomber', material: '100% silk satin', price: 1650, badge: '', color: '#2C1A0E', accent: '#C9A96E' },
      { id: 's5', name: 'Minimal Set', material: 'Cashmere jersey', price: 990, badge: '', color: '#E8E4DC', accent: '#6A6560' },
      { id: 's6', name: 'Gold-Chain Dress', material: 'Stretch crepe, chain detail', price: 1350, badge: 'Limited', color: '#0A0A0A', accent: '#C9A96E' },
    ],
  },
  bridal: {
    titlePlain: 'Bridal',
    titleEm: 'Couture',
    subtitle: 'For the day that stands above all others. Crafted for forever.',
    products: [
      { id: 'b1', name: 'The Aurora', material: 'Duchess satin with French lace', price: 6800, badge: 'Signature', color: '#FDFAF5', accent: '#C9A96E' },
      { id: 'b2', name: 'Seraphine Ballgown', material: 'Tulle & Mikado silk, cathedral train', price: 8500, badge: 'Bestseller', color: '#FAF6F0', accent: '#DFC48E' },
      { id: 'b3', name: 'Garden Silk', material: 'Silk organza with floral embroidery', price: 5200, badge: 'New', color: '#F8F4F0', accent: '#F5C0C3' },
      { id: 'b4', name: 'Minimalist Couture', material: 'Bias-cut silk crêpe', price: 4800, badge: '', color: '#F5F0EA', accent: '#C9A96E' },
      { id: 'b5', name: 'Midnight Bride', material: 'Ivory + black embroidery silk', price: 7200, badge: 'Limited', color: '#1a1a2e', accent: '#FDFAF5' },
      { id: 'b6', name: 'La Parisienne', material: 'Chantilly lace, satin buttons', price: 5600, badge: '', color: '#FDFAF5', accent: '#C9A96E' },
    ],
  },
};

export function formatPrice(n) {
  return '$' + n.toLocaleString('en-US', { minimumFractionDigits: 0 });
}

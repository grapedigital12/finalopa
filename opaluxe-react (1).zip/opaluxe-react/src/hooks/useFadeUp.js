import { useEffect, useRef } from 'react';

/**
 * Attaches an IntersectionObserver to the returned ref so the element
 * gains the "visible" class (triggering the .fade-up CSS transition)
 * the first time it scrolls into view.
 */
export function useFadeUp() {
  const ref = useRef(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -40px 0px' }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return ref;
}
